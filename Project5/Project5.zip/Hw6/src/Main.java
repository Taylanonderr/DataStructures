import java.io.File;
import java.util.Iterator;

public class Main {

    public static void main(String[] args) {
        NLP obje=new NLP();
        obje.readDataset("dataset");
    }
}
