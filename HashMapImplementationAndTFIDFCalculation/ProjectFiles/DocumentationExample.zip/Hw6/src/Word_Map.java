import com.sun.deploy.net.protocol.chrome.ChromeURLConnection;

import java.io.File;
import java.util.*;

public class Word_Map implements Map, Iterable
{

    final static int INITCAP=10;  //initial capacity
    int CURRCAP = INITCAP;   //current capacity
    final static float LOADFACT = 0.75f;
    int numKeys=0;
    private Node table[];
    private Node head=null;
    public Node temp=null;
    public Node selam;
    public Word_Map() {
        head=null;
        this.table = new Node[INITCAP];
    }



    @Override
    public Iterator<Word_Map.Node> iterator() {
        return new Iterator<Word_Map.Node> (){
            private Node temp=head;
            @Override
            public boolean hasNext() {
                if(temp.next==null){
                    return false;
                }
                return true;
            }

            @Override
            public Node next() {
                if(hasNext()) {
                    Node current=temp;
                    temp = temp.next;
                    return current;
                }
                else
                    return null;
            }
        };
    }


    static class Node {
        public Node next;
        private Object key;
        private File_Map Map;

        Node(Object key,Object value){                 /*create node constructure*/
            this.Map= (File_Map) value;
            this.key=key;
            next=null;
        }

        Node(String key, String file_name, int index) {
            Map = new File_Map(file_name, index);
            this.key = key;
        }

        public File_Map getMap(){
            return Map;
        }
        public Object getKey(){
            return key;
        }


        // complete this class according to the given structure in homework definition
    }

    @Override
    public int size() {
        return numKeys;
    }

    @Override
    public boolean isEmpty() {
        if(numKeys==0){
            return true;
        }
        return false;
    }

    @Override
    /*Use linked structure instead of table index
    to perform search operation effectively
     * */
    public boolean containsKey(Object key) {
        int index = find(key);
        return table[index] != null;
    }

    @Override
    /*Use linked structure instead of table index
    to perform search operation effectively
     * */
    public boolean containsValue(Object value) {
        Iterator itr=iterator();
        while (itr.hasNext()) {
            Node temp= (Node) itr.next();
            if(temp.getMap().occurances.contains(value))
                return true;
        }
        return false;
    }

    @Override
    public Object get(Object key) {
        // Find the first table element that is empty
        // or the table element that contains the key.
        int index = find(key);
        // If the search is successful, return the value.
        if (table[index] != null)
            return table[index].getMap();
        else
            return null; // key not found.
    }

    /*I took advantage of the textbook*/
    private int find(Object key) {

        int index = key.hashCode() % table.length;
        if (index < 0)
            index += table.length; // Make it positive.
       /// int index = 0;
        while ((table[index] != null)
                && (!key.equals(table[index].getKey()))) {
            index++;
            // Check for wraparound.
            if (index >= CURRCAP)
                index = 0; // Wrap around.
        }
        return index;
    }


    private Object getValue(String word) {
        for (int i = 0; i < table.length; ++i) {
            if (table[i] != null && table[i].key.equals(word))
                return table[i].Map;
        }
        return null;
    }

    public void helper_add(String word, String file_name, int index) {
        if (containsKey(word)) {
            File_Map cur_fm = (File_Map) getValue(word);
            if (cur_fm.containsKey(file_name)) {
                ArrayList<List<Integer>> cur_fm_val = cur_fm.getOccurances();
                int tf_index = cur_fm.getFnames().indexOf(file_name); // textfile_index
                cur_fm_val.get(tf_index).add(index);
                if(CURRCAP == table.length) {
                    Node temp = head;
                    while (temp.next != null && !temp.getKey().equals(word)) {
                        temp = temp.next;
                    }
                    temp.getMap().getOccurances().get(temp.getMap().getFnames().indexOf(file_name)).add(index);
                }
            }
            else {
                cur_fm.getFnames().add(file_name);
                int tf_index = cur_fm.getFnames().indexOf(file_name);
                cur_fm.getOccurances().add(new ArrayList<>());
                cur_fm.getOccurances().get(tf_index).add(index);
                if(CURRCAP == table.length) {
                    temp = head;
                    while (temp.next != null && !temp.getKey().equals(word)) {
                        temp = temp.next;
                    }
                    temp.getMap().getFnames().add(file_name);
                    temp.getMap().getOccurances().add(new ArrayList<>());
                    temp.getMap().getOccurances().get(temp.getMap().fnames.indexOf(file_name)).add(index);
                }
            }
        }
        else {
            numKeys++;
            double loadFactor = (double) (numKeys ) / table.length;
            if (loadFactor > LOADFACT)
                rehash();
            Node entry = new Node(word, file_name, index);
            int entry_ind = find(word);
            table[entry_ind] = entry;
            if(CURRCAP == table.length) {
                if(head==null) {
                    head=new Node(" ", new File_Map());
                    temp=head;
                    File_Map temp_file=new File_Map();
                    temp_file.put(file_name, index);
                    temp.next = new Node(word, temp_file);
                }
                else {
                    Node temp = head;
                    while (temp.next != null) {
                        temp = temp.next;
                    }
                    File_Map temp_file=new File_Map();
                    temp_file.put(file_name, index);
                    temp.next = new Node(word,temp_file);
                }
            }
        }

    }

    @Override
    /*
    Use linear probing in case of collision
    * */
    public Object put(Object key, Object value) {
        String temp3 = (String) ((ArrayList) value).get(1);
        Integer temp4 = (Integer) ((ArrayList) value).get(2);
        helper_add((String) key,temp3,temp4);
        return null;
    }

    /*I took advantage of the textbook*/
    private void rehash() {
        // Save a reference to oldTable.
        Node[] oldTable = table;
        // Double capacity of this table.
        table = new Node[2 * CURRCAP + 1];
        // Reinsert all items in oldTable into expanded table.
        numKeys = 0;
        clear();
        for (int i = 0; i < oldTable.length; i++) {
            if ((oldTable[i] != null) ) {
                ArrayList<String> temp = oldTable[i].getMap().getFnames();
                for (int j = 0; j < temp.size(); j++) {
                    String temp1 = (String) oldTable[i].getKey();
                    String temp2 = temp.get(j);
                    for (int k = 0; k < oldTable[i].getMap().getOccurances().get(j).size(); k++) {
                        int temp3 = oldTable[i].getMap().getOccurances().get(j).get(k);
                        helper_add(temp1,temp2,temp3);
                    }
                }
            }
        }
        CURRCAP=2 * CURRCAP + 1;
    }


    @Override
    /*You do not need to implement remove function
    * */
    public Object remove(Object key) {
        return null;
    }

    @Override
    public void putAll(Map m) {
        Iterator itr = m.keySet().iterator();
        while (itr.hasNext()) {
            Object k = itr.next();
            Object v = m.get(k);
            put(k, v);
        }
    }

    @Override
    public void clear() {
        for (int i = 0; i < table.length ; i++) {
            table[i] = null;
        }
    }

    @Override
    /*Use linked structure instead of table index
    for efficiency
     * */
    public Set keySet() {
        Set keySet = new HashSet();
        Iterator itr=iterator();
        while (itr.hasNext()) {
            Node temp = (Node) itr.next();
            keySet.add(temp.getKey());
            return keySet;
        }
        return null;
    }

    @Override
    /*Use linked structure instead of table index
    for efficiency
     * */
    public Collection values() {
        Collection values = new ArrayList();
        Iterator itr=iterator();
        while (itr.hasNext()) {
            Node temp = (Node) itr.next();
            values.add(temp.getMap());
            return values;
        }
        return null;
    }

    @Override
    /*You do not need to implement entrySet function
     * */
    public Set<Entry> entrySet() {
        return null;
    }
}