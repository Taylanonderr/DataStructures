import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;
import java.lang.String;
public class NLP
{
    private Word_Map wmap;
    private ArrayList<Integer> file_word_size;
    private ArrayList<String> file_word_name;
    /*You should not use File_Map class in this file since only word hash map is aware of it.
    In fact, you can define the File_Map class as a nested class in Word_Map,
     but for easy evaluation we defined it separately.
     If you need to access the File_Map instances, write wrapper methods in Word_Map class.
    * */

    /*Reads the dataset from the given dir and created a word map */
    public void readDataset(String dir)
    {
        String word;
        String file_name;
        file_word_size=new ArrayList<Integer>();
        file_word_name= new ArrayList<String>();
        wmap=new Word_Map();
        int counter=0;
        File file = new File(dir);
        File[] files = file.listFiles();
        for (File f : files) {
            counter=0;
            file_word_name.add((String)f.getName());
                try {
                    Scanner s = new Scanner(new File(dir+"/"+f.getName()));
                    while (s.hasNext()) {
                        word = s.next().toString();
                        word = word.trim().replaceAll("\\p{Punct}","");
                        if (word.trim().isEmpty()){
                            continue;
                        }
                        ArrayList<Object> x = new ArrayList<Object>();
                        x.add(word);
                        x.add(f.getName());
                        x.add(counter);
                        wmap.put(x.get(0),x);
                        x.clear();
                        counter++;
                    }
                    file_word_size.add(counter);
                } catch (IOException e) {
                     System.out.println("Error accessing input file!");
                }
        }
        printWordMap();

        try {
            Scanner s = new Scanner(new File("input.txt"));
            while (s.hasNext()) {
                word=s.next();
                if(word.equals("bigram")){
                    word=s.next();
                    bigrams(word);

                }
                else if(word.equals("tfidf")){
                    word=s.next();
                    file_name=s.next();
                    tfIDF(word,file_name);
                }
            }
        } catch (IOException e) {
            System.out.println("Error accessing input file!");
        }
    }


    /*Finds all the bigrams starting with the given word*/
    public List<String> bigrams(String word){
        int i=0,j=0,l=0,k,index;
        List<String> bigram_list=new ArrayList<String>();
        Iterator iter=wmap.iterator();
        while(iter.hasNext()){
            Word_Map.Node temp= (Word_Map.Node) iter.next();
            if(word.equals(temp.getKey())){
                i=0;
                while(i<temp.getMap().getFnames().size()){
                    j=0;
                    while(j<temp.getMap().getOccurances().get(i).size()) {
                        index=temp.getMap().getOccurances().get(i).get(j);
                        index++;
                        Iterator value_iter=wmap.iterator();
                        while(value_iter.hasNext()){
                            Word_Map.Node file_map= (Word_Map.Node) value_iter.next();
                            k = 0;
                            while (k < file_map.getMap().getFnames().size()) {
                                l = 0;
                                while (l < file_map.getMap().getOccurances().get(k).size()) {
                                    if (file_map.getMap().getOccurances().get(k).get(l) == index &&
                                            temp.getMap().getFnames().get(i).equals(file_map.getMap().getFnames().get(k))) {
                                        String words=(word + " " +file_map.getKey() );
                                        if(!bigram_list.contains(words)) {
                                            bigram_list.add(words);
                                        }
                                    }
                                    l++;
                                }
                                k++;
                            }
                        }
                        j++;
                    }
                    i++;
                }
            }
        }
        System.out.println(bigram_list.toString()+"\n");
        return bigram_list;
    }


    /*Calculates the tfIDF value of the given word for the given file */
    public float tfIDF(String word, String fileName)
    {
        int i=0,j=0,index=0;
                float total_word=0,total_term=0;
                float tf,tfıdf;
        float idf;
        float time_of_word = 0;
        while(i<file_word_name.size()){
            if(file_word_name.get(i).equals(fileName)){
                Iterator iter=wmap.iterator();
                while (iter.hasNext()){
                    Word_Map.Node temp= (Word_Map.Node) iter.next();
                    if(temp.getKey().equals(word)) {
                        total_word=temp.getMap().getFnames().size();
                        for (j = 0; j < temp.getMap().getFnames().size(); j++) {
                            if (temp.getMap().getFnames().get(j).equals(fileName)) {
                                time_of_word = (int) temp.getMap().getOccurances().get(j).size();
                            }
                        }
                    }
                }
                index=i;
                break;
            }
            i++;
        }
        total_term=file_word_size.size();
        tf=time_of_word/file_word_size.get(index);
        idf=total_term/total_word;
        idf= (float) Math.log(idf);
        tfıdf= (tf*idf);
        System.out.printf("%.7f \n\n",tfıdf);
        return tfıdf;
    }
    
    /*Print the WordMap by using its iterator*/
    public  void printWordMap()
    {
        Iterator iter = wmap.iterator();
        Word_Map.Node temp;
        int i = 0;
        while (iter.hasNext()){
            temp = (Word_Map.Node) iter.next();
            for(i=0;i<temp.getMap().getFnames().size();i++) {
                System.out.printf("Word : %-16s , File name : %-10s \t Occurance List : %s \n",(temp).getKey(),(temp).getMap().getFnames().get(i) ,
                        (temp).getMap().getOccurances().get(i).toString());
            }
        }
    }

}
