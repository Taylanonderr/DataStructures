import java.util.*;

public class File_Map implements Map
{
    /*
    For this hashmap, you will use arraylists which will provide easy but costly implementation.
    Your should provide and explain the complexities for each method in your report.
    * */
    ArrayList<String> fnames;
    ArrayList<List<Integer>> occurances;
    File_Map(){
        fnames=new ArrayList<String>();
        occurances=new ArrayList<List<Integer>>();
    }

    public ArrayList<String> getFnames() {
        return fnames;
    }
    public ArrayList<List<Integer>> getOccurances() {
        return occurances;
    }

    //File_Map(file_name, index);
    public File_Map(String file_name, int index) {
        fnames= new ArrayList<>();
        occurances= new ArrayList<>();
        if (containsKey(file_name)) {
            int tf_index = fnames.indexOf(file_name); // textfile_index
            occurances.get(tf_index).add((Integer) index);
        }
        else {
            fnames.add((String) file_name);
            occurances.add(new ArrayList<>());
            occurances.get(fnames.indexOf(file_name)).add((Integer) index);
        }
    }


    @Override
    public int size() {
        return fnames.size();
    }

    @Override
    public boolean isEmpty() {
        if(size() == 0)
            return true;
        return false;
    }

    @Override
    public boolean containsKey(Object key) {
        return fnames.contains(key);
    }

    @Override
    public boolean containsValue(Object value) {
        return occurances.contains(value);
    }

    @Override
    public Object get(Object key) {
        if (!fnames.contains(key))
            return null;
        return occurances.get(fnames.indexOf(key));
    }

    @Override
    /*Each put operation will extend the occurance list*/
    public Object put(Object key, Object value) {
        if (containsKey(key)) {
            int tf_index = fnames.indexOf(key); // textfile_index
            occurances.get(tf_index).add((Integer) value);
        }
        else {
            fnames.add((String) key);
            occurances.add(new ArrayList<>());
            occurances.get(fnames.indexOf(key)).add((Integer) value);
        }
        return get(key);
    }

    @Override
    public Object remove(Object key) {
        int i = fnames.indexOf(key);
        if (i == -1)
            return null;
        Object old = occurances.get(i);
        fnames.remove(i);
        occurances.remove(i);
        return old;

    }

    @Override
    public void putAll(Map m) {
        Iterator itr = m.keySet().iterator();
        while (itr.hasNext()) {
            Object k = itr.next();
            Object v = m.get(k);
            put(k, v);
        }
    }

    @Override
    public void clear() {
        fnames.clear();
        occurances.clear();
    }

    @Override
    public Set keySet() {
        int i=0;
        Set keySet = new HashSet();
        while (i<fnames.size()) {
            keySet.add(fnames.get(i));
            i++;
        }
        return keySet;
    }

    @Override
    public Collection values() {
        int i=0;
        Collection  values = new ArrayList();
        while (i<occurances.size()) {
            values.add(occurances.get(i));
            i++;
        }
        return values;
    }

    @Override
    public Set<Entry> entrySet() {
        Set entries = new HashSet();
        Iterator key = fnames.iterator(), value = occurances.iterator();
        while (key.hasNext())
            entries.add(new Word_Map.Node(key.next(), value.next()) {
            });
        return entries;

    }
}
